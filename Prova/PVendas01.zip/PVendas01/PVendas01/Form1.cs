﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            Double[,] vendas = new Double[3, 4];
            Double totalVendas = 0;
            String auxiliar;
            String N2;
            String linha = "--------------------------------------------------------------";
            listBox1.Items.Clear();

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {

                    auxiliar = Interaction.InputBox($"Digite o valor das vendas da semana {j+1} do mês {i+1}:", "Entrada de dados");
                    if (!Double.TryParse(auxiliar, out vendas[i, j]) || (vendas[i, j] < 0))
                    {
                        MessageBox.Show("Informe um valor válido (numérico maior ou igual a 0)");
                        j--;
                    }
                    else
                    {
                        totalVendas += vendas[i, j];
                        N2 = vendas[i, j].ToString("N2");
                        auxiliar = $"Total do mês {i + 1}   Semana {j + 1}:  "+ N2 +" R$";
                        listBox1.Items.Add(auxiliar);
                    }

                }
                N2 = ((vendas[i, 0]) + (vendas[i, 1]) + (vendas[i, 2]) + (vendas[i, 3])).ToString("N2");
                auxiliar = $"Vendas totais do mês {i + 1} :  "+ N2 +" R$";
                listBox1.Items.Add(auxiliar);
                listBox1.Items.Add(linha);
            }
            N2 = totalVendas.ToString("N2");
            auxiliar = $">> Total de vendas geral: " + N2;
            listBox1.Items.Add(auxiliar);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}

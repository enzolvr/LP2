﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textAltura = new System.Windows.Forms.TextBox();
            this.textPeso = new System.Windows.Forms.TextBox();
            this.textIMC = new System.Windows.Forms.TextBox();
            this.textClassif = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.Classif = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(76, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Altura (em metros)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(80, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Peso";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(80, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "IMC";
            // 
            // textAltura
            // 
            this.textAltura.Location = new System.Drawing.Point(235, 50);
            this.textAltura.Name = "textAltura";
            this.textAltura.Size = new System.Drawing.Size(112, 26);
            this.textAltura.TabIndex = 3;
            this.textAltura.Validated += new System.EventHandler(this.textAltura_Validated);
            // 
            // textPeso
            // 
            this.textPeso.Location = new System.Drawing.Point(235, 113);
            this.textPeso.Name = "textPeso";
            this.textPeso.Size = new System.Drawing.Size(112, 26);
            this.textPeso.TabIndex = 4;
            this.textPeso.Validated += new System.EventHandler(this.textPeso_Validated);
            // 
            // textIMC
            // 
            this.textIMC.Location = new System.Drawing.Point(235, 173);
            this.textIMC.Name = "textIMC";
            this.textIMC.ReadOnly = true;
            this.textIMC.Size = new System.Drawing.Size(112, 26);
            this.textIMC.TabIndex = 5;
            // 
            // textClassif
            // 
            this.textClassif.Location = new System.Drawing.Point(235, 230);
            this.textClassif.Name = "textClassif";
            this.textClassif.ReadOnly = true;
            this.textClassif.Size = new System.Drawing.Size(338, 26);
            this.textClassif.TabIndex = 6;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(84, 299);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 32);
            this.btnCalcular.TabIndex = 7;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(246, 299);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 32);
            this.btnLimpar.TabIndex = 8;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Classif
            // 
            this.Classif.AutoSize = true;
            this.Classif.Location = new System.Drawing.Point(76, 230);
            this.Classif.Name = "Classif";
            this.Classif.Size = new System.Drawing.Size(102, 20);
            this.Classif.TabIndex = 9;
            this.Classif.Text = "Classificação";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Classif);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.textClassif);
            this.Controls.Add(this.textIMC);
            this.Controls.Add(this.textPeso);
            this.Controls.Add(this.textAltura);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textAltura;
        private System.Windows.Forms.TextBox textPeso;
        private System.Windows.Forms.TextBox textIMC;
        private System.Windows.Forms.TextBox textClassif;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label Classif;
    }
}


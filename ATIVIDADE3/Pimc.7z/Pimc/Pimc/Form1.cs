﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double altura, peso, imc;

        private void textPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(textPeso.Text, out peso) || (peso <= 0))
            {
                MessageBox.Show("Peso inválido.");
                textPeso.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            textAltura.Clear();
            textPeso.Clear();
            textIMC.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            textIMC.Text = imc.ToString("N1");

            imc = Math.Round(imc, 1);

            if (imc < 16.5)
            {
                textClassif.Text = "Abaixo do peso (Obesidade Grau 0";
            }
            else if ((imc >= 16.5) && (imc <= 24.9))
            {
                textClassif.Text = "Peso ideal (Obesidade Grau 0)";
            }
            else if ((imc >= 25) && (imc <= 29.9))
            {
                textClassif.Text = "Sobrepeso (Obesidade Grau I)";
            }
            else if ((imc >= 30) && (imc <= 39.9))
            {
                textClassif.Text = "Obesidade (Obesidade Grau II)";
            }
            else if (imc > 40)
            {
                textClassif.Text = "Obesidade grave (Obesidade Grau III)";
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void textAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(textAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura inválida.");
                textAltura.Focus();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out ladoA ))
            {
                MessageBox.Show("Valor inválido");
                txtLadoA.Focus();
            }
        }
        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out ladoB))
            {
                MessageBox.Show("Valor inválido");
                txtLadoB.Focus();
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Valor inválido");
                txtLadoC.Focus();
            }
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            if ( ladoA < (ladoB + ladoC) && ladoA > Math.Abs(ladoB - ladoC) &&
                ladoB < (ladoA + ladoC) && ladoB > Math.Abs(ladoA - ladoC) &&
                ladoC < (ladoA + ladoB) && ladoC > Math.Abs(ladoA - ladoB))
            {
                if ( ladoA == ladoB && ladoB == ladoC )
                    MessageBox.Show("É um triângulo do tipo equilátero.");
                else if ((ladoA == ladoB && lado)
            }

            else
                {
                MessageBox.Show("Não é triângulo");
                }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Ex5 : Form
    {
        public Ex5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            String[,] alunosNotas = new string[9, 10];
            String[] gabarito = { "E", "C", "B", "A", "D", "A", "B", "E", "D", "C" };
            String auxiliar;

            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    alunosNotas[i, j] = Interaction.InputBox($"Digite a resposta do aluno {i + 1} para a questão {j + 1}: ");
                    if (alunosNotas[i, j].ToUpper() == "A" || alunosNotas[i, j].ToUpper() == "B" || alunosNotas[i, j].ToUpper() == "C" || alunosNotas[i, j].ToUpper() == "D" || alunosNotas[i, j].ToUpper() == "E")
                    {
                        if (alunosNotas[i, j].ToUpper() == gabarito[j])
                        {
                            auxiliar = $"O aluno {i + 1} acertou a questão {j + 1}. A resposta era {gabarito[j]}";

                        }
                        else
                        {
                            auxiliar = $"O aluno {i + 1} errou a questão {j + 1}. A resposta era {gabarito[j]}, o aluno escolheu {alunosNotas[i, j]}";
                        }

                        listBox1.Items.Add(auxiliar);
                    }
                    else
                    {
                        MessageBox.Show("Resposta inválida. Digite novamente.");
                        j--;
                    }
                }
            }
        }
    }
}


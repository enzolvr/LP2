﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Ex4 : Form
    {
        public Ex4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            String[] nomes = new String[10];
            int[] tamanho = new int[10];
            String auxiliar;
            for (int i = 0; i < 10; i++)
            {
                nomes[i] = Interaction.InputBox("Digite o nome: ");
                auxiliar = nomes[i].Replace(" ", "");
                tamanho[i] = auxiliar.Length;
                auxiliar = $"Nome: {nomes[i]} , Tamanho: {tamanho[i]}";
                listBox1.Items.Add(auxiliar);

                {

                }
            }
        }
    }
}

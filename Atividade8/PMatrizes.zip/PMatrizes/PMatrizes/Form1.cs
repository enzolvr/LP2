﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            String auxiliar = "";

            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}º número", "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";
            auxiliar = String.Join("\n", vetor);

            MessageBox.Show(auxiliar);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Beatriz", "Camila", "João",
                                                "Joana", "Otávio", "Marcelo", "Pedro", "Thais" };

            lista.Remove("Otávio");
            String auxiliar = "";
            foreach(String nome in lista)
                auxiliar += nome + "\n";

            MessageBox.Show(auxiliar);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            Double[,] notas = new Double[20, 3];
            Double media = 0;
            String saida = "";
            String auxiliar = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Entrada de dados");
                    if (!(Double.TryParse(auxiliar, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10))
                    {
                        MessageBox.Show("Dado inválido");
                        j--;
                    }
                    else
                    {
                        media += notas[i, j];
                    }

                }
                saida += $"\nAluno {i + 1}: Média {media / 3}";
                media = 0;
                MessageBox.Show(saida);
            }
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Ex4>().Count() > 0)
            {
                MessageBox.Show("Formulário já existe");
                Application.OpenForms["Ex4"].BringToFront();
            }
            else
            {
                Ex4 Exercicio4 = new Ex4();
                Exercicio4.Show();
            }
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Ex5>().Count() > 0)
            {
                MessageBox.Show("Formulário já existe");
                Application.OpenForms["Ex5"].BringToFront();
            }
            else
            {
                Ex5 Exercicio5 = new Ex5();
                Exercicio5.Show();
            }
        }
    }
}

﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {

        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            Double[,] notas = new Double[20, 3];
            Double media = 0;
            String saida = "";
            String auxiliar = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Entrada de dados");
                    if (!(Double.TryParse(auxiliar, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10))
                    {
                        MessageBox.Show("Dado inválido");
                        j--;
                    }
                    else
                    {
                        media += notas[i, j];
                    }

                }
                saida += $"\nAluno {i + 1}: Média {media / 3}";
                media = 0;
                MessageBox.Show(saida);
            }
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Ex4>().Count() > 0)
            {
                MessageBox.Show("Formulário já existe");
                Application.OpenForms["Ex4"].BringToFront();
            }
            else
            {
                Ex4 Exercicio4 = new Ex4();
                Exercicio4.Show();
            }
        }
    }
}
